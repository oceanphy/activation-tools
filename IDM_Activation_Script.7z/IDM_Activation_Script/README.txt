注：该脚本可能被安全软件拦截，请手动关闭安全软件。

1. 在官网下载并安装 IDM。（https://www.internetdownloadmanager.com）

2. 右键以管理员身份启动 IDM_6.4x_Crack.exe。

3. 点击左侧“Crack”按钮即可自动激活 IDM，稍等片刻后中央按钮变成“Finsh”，则代表激活完成。

4. 点击“Finsh”按钮关闭脚本，然后手动重启 IDM，点击“注册”按钮，显示“本软件已注册”。

5. IDM 更新后，重复步骤 2~4 即可重新激活。